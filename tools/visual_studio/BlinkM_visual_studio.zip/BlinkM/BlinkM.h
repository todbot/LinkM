#pragma once

extern "C" {
#include "linkm-lib.h"
}

#include <string>
using namespace std;

class BlinkM
{
public:
	BlinkM(void);
	void SetColor(unsigned char R, unsigned char G, unsigned char B);
	~BlinkM(void);
	string GetLastError() {return lastError;}
private:
	usbDevice_t *dev;
	int err;
	string lastError;
};
