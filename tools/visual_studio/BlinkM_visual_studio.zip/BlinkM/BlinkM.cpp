#include "BlinkM.h"

BlinkM::BlinkM(void)
{
	if( (err = linkm_open( &dev )) ) {
		lastError = "Error opening LinkM: "+string(linkm_error_msg(err))+"\n";
	}
}

BlinkM::~BlinkM(void)
{
	linkm_close(dev);
}

void BlinkM::SetColor(unsigned char R, unsigned char G, unsigned char B)
{
	uint8_t cmdbuf[8] = {0, 'c', R,G,B};
	if (err = linkm_command(dev, LINKM_CMD_I2CTRANS, 5,0, cmdbuf, NULL)) {
		lastError = "error on color cmd: "+string(linkm_error_msg(err))+"\n";
	}
}

